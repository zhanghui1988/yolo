# animals > release
https://universe.roboflow.com/object-detection/animals-ij5d2

Provided by Roboflow
License: CC BY 4.0

